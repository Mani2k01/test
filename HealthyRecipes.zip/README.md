# HealthyRecipes

This is an open-source collection of healthy recipes categorized by meal types such as breakfast, lunch, dinner, and snacks. The goal is to collaborate and share simple, nutritious meals.

## Folder Structure
- `data/`: Contains CSV files of recipes
- `recipes/`: Markdown files of individual recipes
- `website/`: HTML, CSS, and JS files for GitHub Pages
- `.github/workflows/`: GitHub Actions for automation

## Getting Started
1. Fork this repository
2. Clone it to your local machine
3. Add your own recipe (as a Markdown file or in a CSV)
4. Push your changes and open a Pull Request

## How to Contribute
- Add a new recipe in `recipes/` or update existing ones
- Add a new entry in `data/` CSVs with proper formatting
- Improve the website design or functionality
