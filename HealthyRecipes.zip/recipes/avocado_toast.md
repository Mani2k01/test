# Avocado Toast

**Prep Time:** 10 minutes  
**Calories:** 250

## Ingredients
- 1 ripe avocado
- 2 slices whole-grain bread
- 1 tsp lemon juice
- Salt to taste

## Instructions
1. Toast the bread.
2. Mash avocado with lemon juice and salt.
3. Spread on toast and enjoy.

## Tags
`#vegan` `#quick` `#healthy`
