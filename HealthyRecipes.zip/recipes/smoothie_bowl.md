# Smoothie Bowl

**Prep Time:** 8 minutes  
**Calories:** 280

## Ingredients
- 1 banana
- 1/2 cup mixed berries
- 1/2 cup yogurt
- 1 tbsp chia seeds

## Instructions
1. Blend all ingredients until smooth.
2. Pour into a bowl and top with fresh fruits or nuts.

## Tags
`#vegan` `#breakfast` `#lowfat`
